package com.example.boredapi;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {
    private final String url = "http://www.boredapi.com/api/activity/";
    TextView textview_activity;
    TextView textview_link;
    TextView textview_price;
    TextView textview_type;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
    }
    void init() {
        textview_activity = findViewById(R.id.activity);
        textview_link = findViewById(R.id.link);
        textview_price = findViewById(R.id.price);
        textview_type = findViewById(R.id.type);
    }
    public void getBoredApiDetails(View view) {
        StringRequest request = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonResponse = new JSONObject(response);
                    String activity = jsonResponse.getString("activity");
                    String link = jsonResponse.getString("link");
                    String type = jsonResponse.getString("type");
                    Double price = jsonResponse.getDouble("price");
                    Double accessibility = jsonResponse.getDouble("accessibility");

                        textview_activity.setText(activity);
                    if (link.length()==0){
                        textview_link.setText("Link error");


                    }else{
                        textview_link.setText(link);
                    }
                        textview_type.setText(type);

                        textview_price.setText(price+" $");

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(),
                        error.toString().trim(),
                        Toast.LENGTH_SHORT).show();
            }
        });
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(request);
    }
}
