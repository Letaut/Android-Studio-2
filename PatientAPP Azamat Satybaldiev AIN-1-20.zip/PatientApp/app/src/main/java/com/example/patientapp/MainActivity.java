package com.example.patientapp;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import com.example.patientapp.db.Database;
import com.example.patientapp.entity.Patient;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private PatientAdapter patientAdapter;
    private List<Patient> Patients;
    private RecyclerView recyclerView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button addNewUserButton = findViewById(R.id.Button);
        addNewUserButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivityForResult(new Intent(MainActivity.this, NewUser.class),100);
            }
        });
        initRecyclerView();
        loadUserList();
    }
    private void initRecyclerView() {
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(this,DividerItemDecoration.VERTICAL);
        recyclerView.addItemDecoration(dividerItemDecoration);

        patientAdapter = new PatientAdapter(this);




        recyclerView.setAdapter(patientAdapter);
        new ItemTouchHelper(simpleCallback).attachToRecyclerView(recyclerView);
    }
    private void loadUserList(){
        Database database = Database.getDbInstance(this.getApplicationContext());
        Patients = database.Patient().getAllPatients();
        patientAdapter.setPatientList(Patients);
    }
    ItemTouchHelper.SimpleCallback simpleCallback = new ItemTouchHelper.SimpleCallback(0,ItemTouchHelper.RIGHT) {
        @Override
        public boolean onMove(@NonNull RecyclerView recyclerView,
                              @NonNull RecyclerView.ViewHolder viewHolder,
                              @NonNull RecyclerView.ViewHolder target) {
            return false;
        }
        @Override
        public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
            Patients.remove(viewHolder.getAdapterPosition());
            patientAdapter.notifyDataSetChanged();
        }
    };
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if(requestCode==100){
            loadUserList();
        }
        super.onActivityResult(requestCode, resultCode, data);
    }



}