package com.example.patientapp.db;


import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import com.example.patientapp.entity.Patient;

import java.util.List;

@Dao
public interface PatientDao {

    @Query(value = "SELECT * FROM patient")
    List<Patient> getAllPatients();


    @Insert
    void insert(Patient... patient);

    @Delete
    void delete(Patient patient);

}
