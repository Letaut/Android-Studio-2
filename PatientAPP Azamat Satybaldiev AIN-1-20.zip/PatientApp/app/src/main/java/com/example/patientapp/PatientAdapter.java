package com.example.patientapp;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.patientapp.entity.Patient;

import java.util.List;
public class PatientAdapter extends RecyclerView.Adapter<PatientAdapter.MyViewHolder> {
    private Context context;
    private List<Patient> patients;
    public PatientAdapter(Context context) {
        this.context = context;
    }
    public void setPatientList(List<Patient> patients) {
        this.patients = patients;
        notifyDataSetChanged();
    }
    @NonNull
    @Override
    public PatientAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(context).inflate
                (R.layout.pacient,parent,false);
        return new MyViewHolder(view);
    }
    @Override
    public void onBindViewHolder(@NonNull PatientAdapter.MyViewHolder holder, int position) {
        holder.FirstName.setText(this.patients.get(position).getName());
        holder.SecondName.setText(this.patients.get(position).getSurname());
        holder.PhoneNumber.setText(this.patients.get(position).getPhoneNumber());
        holder.layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
           /*Toast.makeText(context,"Ваше место находится в очереди...: ",Toast.LENGTH_SHORT);*/

                Toast.makeText(view.getContext(), "Ваше место находится в очереди", Toast.LENGTH_LONG).show();

                

            }
        });
    }




    @Override
    public int getItemCount() {
        return patients.size();
    }
    public class MyViewHolder extends RecyclerView.ViewHolder{
        TextView FirstName;
        TextView SecondName;
        TextView PhoneNumber;


        LinearLayout layout;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            FirstName = itemView.findViewById(R.id.name);
            SecondName = itemView.findViewById(R.id.surname);
            PhoneNumber = itemView.findViewById(R.id.number);
            layout = itemView.findViewById(R.id.linear_layout);
        }
    }

}
