package com.example.patientapp.db;

import android.content.Context;

import androidx.room.Room;
import androidx.room.RoomDatabase;

import com.example.patientapp.entity.Patient;

@androidx.room.Database(entities = {Patient.class},version = 1)
public abstract class Database extends RoomDatabase {
    public abstract PatientDao Patient();
    private static Database INSTANCE;
    public static Database getDbInstance(Context context){
        if(INSTANCE == null){
            INSTANCE = Room.databaseBuilder(context.getApplicationContext(),Database.class,"Patient_DB").allowMainThreadQueries().build(); }
        return INSTANCE;
    }

}
