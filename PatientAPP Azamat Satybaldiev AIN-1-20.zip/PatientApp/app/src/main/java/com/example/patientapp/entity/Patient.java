package com.example.patientapp.entity;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;
@Entity
public class Patient {

    @PrimaryKey(autoGenerate = true)
    private int id;
    @ColumnInfo(name = "FirstName")
    private String name;
    @ColumnInfo(name = "SecondName")
    private String surname;
    @ColumnInfo(name = "PhoneNumber")
    private String phoneNumber;
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getSurname() {
        return surname;
    }
    public void setSurname(String surname) {
        this.surname = surname;
    }
    public String getPhoneNumber() {
        return phoneNumber;
    }
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
}
