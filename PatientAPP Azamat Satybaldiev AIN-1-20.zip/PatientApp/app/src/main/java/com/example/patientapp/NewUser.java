package com.example.patientapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.patientapp.db.Database;
import com.example.patientapp.entity.Patient;

public class NewUser extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_new_user);

        EditText Firstname = findViewById(R.id.nameInput);
        EditText Secondname = findViewById(R.id.surnameInput);
        EditText phoneNumber = findViewById(R.id.phoneInput);
        Button saveButton = findViewById(R.id.add);
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                save(Firstname.getText().toString(),Secondname.getText().toString(),phoneNumber.getText().toString());
            }
        });
    }

    private void save(String name,String surname,String phoneNumber){
        Database database = Database.getDbInstance(this.getApplicationContext());
        Patient patient = new Patient();

        patient.setName(name);
        patient.setSurname(surname);
        patient.setPhoneNumber(phoneNumber);

        database.Patient().insert(patient);
        finish();
    }

}